import { useNavigation } from '@react-navigation/native';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Alert, Text, AsyncStorage, InteractionManager, Modal, TouchableOpacity } from 'react-native';
import { APP_URLS } from '../../../utils/network/urls';
import useAxiosHook from '../../../utils/network/AxiosClient';
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import AdharPay from './aadharpay';
import BalanceCheck from './Balancecheck';
import { hScale, SCREEN_WIDTH, wScale } from '../../../utils/styles/dimensions';
import AepsMinistatement from './AepsMinistatement';
import AepsCW from './AepsCashwithdrawl';
import { AepsContext } from './context/AepsContext';
import { useSelector } from 'react-redux';
import { RootState } from '../../../reduxUtils/store';
import { colors } from '../../../utils/styles/theme';
import CheckBlance from '../../../utils/svgUtils/CheckBlance';
import Aeps from '../../../utils/svgUtils/Aeps';
import AadharPaysvg from '../../../utils/svgUtils/AadhaarPaysvg';
import StatementSvg from '../../../utils/svgUtils/StatementSvg';
import { setActiveAepsLine } from '../../../reduxUtils/store/userInfoSlice';
import { useDispatch } from 'react-redux';
const AepsTabScreen = ({ }) => {
  const { colorConfig, activeAepsLine } = useSelector((state: RootState) => state.userInfo);
  const color1 = `${colorConfig.primaryColor}20`;
  const navigation = useNavigation<any>();
  const [fingerprintData, setFingerprintData] = useState<any>();
  const [aadharNumber, setAadharNumber] = useState('');
  const [bankName, setBankName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [consumerName, setConsumerName] = useState('');
  const { get } = useAxiosHook();
  const [index, setIndex] = useState(0);
  const [isValid, setIsValid] = useState(false);

  const [routes] = useState([
    { key: 'AepsCW', title: 'Aeps' },
    { key: 'BalanceCheck', title: 'Check Bal' },
    { key: 'AepsMiniStatement', title: 'M. Statement' },

    { key: 'AadharPay', title: 'Aadhar Pay' },
  ]);
  const getSvgimg = (key: string) => {
    switch (key) {
      case 'AepsCW':
        return <AadharPaysvg />
      case 'BalanceCheck':
        return <CheckBlance />
      case 'AadharPay':
        return <Aeps />
      case 'AepsMiniStatement':
        return <StatementSvg />
      default:
        return null;
    }
  }
  const [isSuccess, setIsSucess] = useState(false);
  const CheckAeps = async () => {
    try {
      const url = `AEPS/api/data/AepsStatusCheck`;
      const url2 = `AEPS/api/Nifi/data/AepsStatusCheck`;

      const response = await get({ url: activeAepsLine ? url2 : url });

      const msg = response.Message;
      const status = response.Response;
      if (response.Response == 'Success') {
        //start();

        setUserStatus('Success');
        setIsSucess(status === 'Success')
        if (fingerprintData === 720) {
          // start();
        }
      } else if (status === 'BOTHNOTDONE' || status === 'NOTOK' || status === 'ALLNOTDONE' || msg === 'PURCHASE') {


        navigation.navigate('ServicepurchaseScreen', { typename: 'AEPS' });
      } else if (msg === 'OTPREQUIRED') {

      } else {
        Alert.alert('', msg, [
          { text: 'OK', onPress: () => console.log('OK Pressed') },
        ], { cancelable: false });
      }

    } catch (error) {
      console.log(error);
    } finally {
    }
  };
  const renderScene = SceneMap({
    'BalanceCheck': BalanceCheck,
    'AepsMiniStatement': AepsMinistatement,
    'AepsCW': AepsCW,
    'AadharPay': AdharPay,

  });

  useEffect(()=>{
dispatch(setActiveAepsLine(true))
  },[])
  const [UserStatus, setUserStatus] = useState('');
  const dispatch = useDispatch();
  const [showEkycModal, setShowEkycModal] = useState(false);
  const [loading, setLoading] = useState(false); // ⬅️ Loop rokne ke liye
  const hasCheckedEkyc = useRef(false); // ⬅️ Strict check ke liye
  const isApiCalling = useRef(false); // 🔒 Lock 1: Request progress check
  const isCheckDone = useRef(false);
  const CheckEkyc = useCallback(async () => {
    // Agar ek baar check ho chuka hai ya abhi call chal rahi hai, toh turant bahar nikal jao
    if (isCheckDone.current || isApiCalling.current) {
      return;
    }

    try {
      isApiCalling.current = true; // Request shuru, lock lagao

      const url1 = APP_URLS.checkekyc;
      const url2 = `AEPS/api/Nifi/data/CheckEkyc`;
      const finalUrl = activeAepsLine ? url2 : url1;

      console.log("🔗 Final URL:", finalUrl);

      const response = await get({ url: finalUrl });
      console.log("📩 EKYC Response:", response);

      const msg = response?.Message;
      const status = response?.Status;

      // Sabse pehle mark kar do ki ek baar check ho gaya
      isCheckDone.current = true;

      // ✅ SUCCESS
      if (status === true) {
        CheckAeps();
        return;
      }

      // ✅ 2FA REQUIRED
      if (msg === '2FAREQUIRED') {
        setUserStatus('Success');
        return;
      }

      // ✅ OTP REQUIRED
      if (msg === 'REQUIREDOTP') {
        setUserStatus(msg);
        setShowEkycModal(true);
        dispatch(setActiveAepsLine(activeAepsLine))
        return;
      }

      // ✅ SCAN REQUIRED
      if (msg === 'REQUIREDSCAN') {
        setUserStatus(msg);
        navigation.navigate("Aepsekycscan");

        return;
      }

      // Default/Error Notice
      Alert.alert("Notice", msg || "Unknown server error", [{ text: "OK", onPress: () => navigation.goBack() }]);

    } catch (error) {
      console.log("❌ CheckEkyc Error:", error);
      // Agar error aaye aur aap chahte ho ki user dobara try kare, toh isCheckDone ko false kar sakte ho
      isCheckDone.current = false;
    } finally {
      isApiCalling.current = false; // Request khatam, lock kholo
    }
  }, [activeAepsLine, CheckAeps, navigation, get]);

  // 🔄 UseEffect ko bilkul simple rakho bina kisi dependency ke
  useEffect(() => {
    CheckEkyc();
  }, []); // ⬅️ Dependency array empty rakhein

  const [deviceName, setDeviceName] = useState('Device');
  const [bankid, setBankId] = useState('');

  if (showEkycModal) {

    return (

      <Modal
        visible={showEkycModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowEkycModal(false)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(0,0,0,0.5)",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: "85%",
              backgroundColor: "#fff",
              borderRadius: 12,
              padding: 20,
            }}
          >
            {/* Title */}
            <Text
              style={{
                fontSize: 18,
                fontWeight: "700",
                marginBottom: 10,
                color: "#000",
              }}
            >
              Green Line
            </Text>

            {/* Message */}
            <Text
              style={{
                fontSize: 14,
                color: "#555",
                marginBottom: 20,
              }}
            >
              Greenline aeps require OTP verification.
              Please choose one option..
              Please choose an option below.
            </Text>

            {/* Action Buttons */}
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <TouchableOpacity
                onPress={() => {
                  // setShowEkycModal(false);
                  // dispatch(setActiveAepsLine(!activeAepsLine));

                  navigation.goBack()
                }}
              >
                <Text
                  style={{
                    color: "#f0a500",
                    fontWeight: "600",
                    fontSize: 14,
                  }}
                >
                  Go Back
                  {/* Switch to Yellow Line */}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  setShowEkycModal(false);
                  navigation.replace("Aepsekyc");
                }}
                style={{
                  backgroundColor: "#1e7e34",
                  paddingVertical: 8,
                  paddingHorizontal: 14,
                  borderRadius: 6,
                }}
              >
                <Text
                  style={{
                    color: "#fff",
                    fontWeight: "600",
                    fontSize: 14,
                  }}
                >
                  Complete eKYC
                </Text>
              </TouchableOpacity>
            </View>

            {/* Cancel */}
            <TouchableOpacity
              onPress={() => { setShowEkycModal(false); }}
              style={{ marginTop: 18, alignItems: "center" }}
            >
              <Text
                style={{
                  color: "#999",
                  fontSize: 13,
                }}
              >
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>


    )
  }

  return (

    <AepsContext.Provider value={{
      fingerprintData,
      setFingerprintData,
      aadharNumber,
      setAadharNumber,
      consumerName,
      setConsumerName,
      mobileNumber,
      bankName,
      setBankName,
      scanFingerprint: null,
      setMobileNumber,
      setIsValid,
      isValid,
      setDeviceName,
      deviceName,
      setBankId,
      bankid
    }}>

      <View style={styles.container}>


        {(() => {
          switch (UserStatus) {
            case 'Success':
              return (
                <View style={styles.container}>

                  <TabView
                    lazy
                    navigationState={{ index, routes }}
                    renderScene={renderScene}
                    onIndexChange={setIndex}
                    initialLayout={{ width: SCREEN_WIDTH }}
                    renderTabBar={(props) => (
                      <TabBar
                        {...props}
                        indicatorStyle={[styles.indicator, { backgroundColor: colorConfig.primaryColor }]}
                        style={[styles.tabbar, { backgroundColor: color1 }]}
                        renderLabel={({ route, focused }) => (
                          <View style={styles.labelview}>
                            {getSvgimg(route.key)}
                            <Text style={[styles.labelstyle, { color: focused ? colors.dark_black : colors.black75 }]}>
                              {route.title}
                            </Text>
                          </View>
                        )}
                      />
                    )}
                  />

                </View>
              );

            default:
              // navigation.navigate("Home");
              return null; // Return null for the default case
          }
        })()}
      </View>


    </AepsContext.Provider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff"
  },
  tabbar: {
    elevation: 0,
    marginBottom: hScale(10),
    height: hScale(60)
  },
  indicator: {
  },
  labelstyle: {
    fontSize: wScale(13),
    color: colors.black,
    width: "100%",
    textAlign: 'center',
  },
  labelview: {
    alignItems: 'center',
    flex: 1,
  }
});

export default AepsTabScreen;