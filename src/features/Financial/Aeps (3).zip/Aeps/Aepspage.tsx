import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  ToastAndroid,
} from 'react-native';
import { TabView, TabBar } from 'react-native-tab-view';
import { useDispatch, useSelector } from 'react-redux';

import { APP_URLS } from '../../../utils/network/urls';
import useAxiosHook from '../../../utils/network/AxiosClient';
import { RootState } from '../../../reduxUtils/store';
import { setActiveAepsLine } from '../../../reduxUtils/store/userInfoSlice';

import AppBarSecond from '../../drawer/headerAppbar/AppBarSecond';
import CheckSvg from '../../drawer/svgimgcomponents/CheckSvg';
import AepsTabScreen from './AepsTabScreen';
import ShowLoader from '../../../components/ShowLoder';
import { hScale, wScale } from '../../../utils/styles/dimensions';

const { width } = Dimensions.get('window');

// 👇 IMPORTANT: memoized screen
const MemoAepsTab = React.memo(AepsTabScreen);

const AepsScreen = () => {
  const dispatch = useDispatch();
  const { post } = useAxiosHook();

  const { activeAepsLine } = useSelector(
    (state: RootState) => state.userInfo
  );

  const [index, setIndex] = useState(activeAepsLine ? 0 : 1);
  const [isLoading, setIsLoading] = useState(false);
  const isFirstLoad = useRef(true);

  const routes = [
    { key: 'green', title: 'Green Line AEPS' },
    { key: 'yellow', title: 'Yellow Line AEPS' },
  ];

  // ✅ SINGLE API GATE
  const checkAeps = useCallback(async (requestedLine: number) => {
    if (isLoading) return;

    setIsLoading(true);
    try {
      const res = await post({ url: APP_URLS.AepsStatusCheck });
      const { status1, status2 } = res;

      if (requestedLine === 1) {
        if (status1) dispatch(setActiveAepsLine(true));
        else {
          ToastAndroid.show('Green Line closed', ToastAndroid.SHORT);
          setIndex(1);
          dispatch(setActiveAepsLine(false));
        }
      } else {
        if (status2) dispatch(setActiveAepsLine(false));
        else {
          ToastAndroid.show('Yellow Line closed', ToastAndroid.SHORT);
          setIndex(0);
          dispatch(setActiveAepsLine(true));
        }
      }
    } finally {
      setIsLoading(false);
    }
  }, [isLoading]);

  // ✅ initial check only once
  useEffect(() => {
    if (isFirstLoad.current) {
      isFirstLoad.current = false;
      checkAeps(index === 0 ? 1 : 2);
    }
  }, []);

  // ✅ MANUAL renderScene (NO SceneMap)
  const renderScene = useCallback(({ route }) => {
    return <MemoAepsTab />;
  }, []);

  const handleIndexChange = (newIndex: number) => {
    if (newIndex === index) return; // ⛔ no re-render
    setIndex(newIndex);
    checkAeps(newIndex === 0 ? 1 : 2);
  };

  const renderTabBar = (props: any) => (
    <TabBar
      {...props}
      indicatorStyle={{ height: 0 }}
      style={{ backgroundColor: 'transparent', elevation: 0 }}
      renderLabel={({ route, focused }) => {
        const isGreen = route.key === 'green';
        return (
          <View
            style={[
              styles.tabButton,
              { width: width * 0.48 },
              { backgroundColor: isGreen ? '#1FAA59' : '#F4C430' },
              focused && styles.activeTab,
            ]}
          >
            {focused && (
              <View style={styles.check}>
                <CheckSvg color={isGreen ? '#1FAA59' : '#F4C430'} size={16} />
              </View>
            )}
            <Text style={styles.tabText}>{route.title}</Text>
          </View>
        );
      }}
    />
  );

  return (
    <View style={styles.container}>
      <AppBarSecond title="AEPS / AADHAAR PAY" actionButton={undefined} onActionPress={undefined} onPressBack={undefined} titlestyle={undefined} />

      <TabView
        lazy
        swipeEnabled={false}
        navigationState={{ index, routes }}
        renderScene={renderScene}
        renderTabBar={renderTabBar}
        onIndexChange={handleIndexChange}
      />

      {isLoading && <ShowLoader />}
    </View>
  );
};

export default AepsScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FB',
  },

  /* ---------------- TAB BUTTON ---------------- */
  tabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: hScale(10),
    borderRadius: 8,
  },

  activeTab: {
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },

  tabText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },

  check: {
    backgroundColor: '#FFFFFF',
    borderRadius: 50,
    padding: wScale(3),
    marginRight: wScale(6),
    alignItems: 'center',
    justifyContent: 'center',
  },

  /* ---------------- TAB BAR WRAPPER ---------------- */
  tabBar: {
    backgroundColor: 'transparent',
    elevation: 0,
  },

  /* ---------------- SCREEN CONTENT ---------------- */
  contentContainer: {
    flex: 1,
    paddingHorizontal: wScale(12),
    paddingTop: hScale(8),
  },
});
