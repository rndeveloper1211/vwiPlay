import { useNavigation } from '@react-navigation/native';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  View,
  StyleSheet,
  Alert,
  Text,
  Modal,
  TouchableOpacity,
} from 'react-native';
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import { useSelector, useDispatch } from 'react-redux';

import { APP_URLS } from '../../../utils/network/urls';
import useAxiosHook from '../../../utils/network/AxiosClient';
import { hScale, SCREEN_WIDTH, wScale } from '../../../utils/styles/dimensions';
import { colors } from '../../../utils/styles/theme';

import AdharPay from './aadharpay';
import BalanceCheck from './Balancecheck';
import AepsMinistatement from './AepsMinistatement';
import AepsCW from './AepsCashwithdrawl';

import { AepsContext } from './context/AepsContext';
import { RootState } from '../../../reduxUtils/store';

import CheckBlance from '../../../utils/svgUtils/CheckBlance';
import Aeps from '../../../utils/svgUtils/Aeps';
import AadharPaysvg from '../../../utils/svgUtils/AadhaarPaysvg';
import StatementSvg from '../../../utils/svgUtils/StatementSvg';

const AepsTabScreen = () => {
  const navigation = useNavigation<any>();
  const dispatch = useDispatch();
  const { get } = useAxiosHook();

  // Get active line from Redux (Updated by Parent Screen)
  const { colorConfig, activeAepsLine } = useSelector(
    (state: RootState) => state.userInfo
  );

  const color1 = `${colorConfig.primaryColor}90`;

  /* -------------------- STATE -------------------- */
  const [index, setIndex] = useState(0);
  const [UserStatus, setUserStatus] = useState('');
  const [showEkycModal, setShowEkycModal] = useState(false);

  // Context States
  const [fingerprintData, setFingerprintData] = useState<any>();
  const [aadharNumber, setAadharNumber] = useState('');
  const [bankName, setBankName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [consumerName, setConsumerName] = useState('');
  const [isValid, setIsValid] = useState(false);
  const [deviceName, setDeviceName] = useState('Device');
  const [bankid, setBankId] = useState('');

  /* -------------------- LOCKS -------------------- */
  const isApiCalling = useRef(false);
  const isCheckDone = useRef(false);

  /* -------------------- TABS CONFIG -------------------- */
  const routes = [
    { key: 'AepsCW', title: 'Aeps' },
    { key: 'BalanceCheck', title: 'Check Bal' },
    { key: 'AepsMiniStatement', title: 'M. Statement' },
    { key: 'AadharPay', title: 'Aadhar Pay' },
  ];

  const renderScene = SceneMap({
    AepsCW: AepsCW,
    BalanceCheck: BalanceCheck,
    AepsMiniStatement: AepsMinistatement,
    AadharPay: AdharPay,
  });

  const getSvgimg = (key: string) => {
    switch (key) {
      case 'AepsCW': return <AadharPaysvg />;
      case 'BalanceCheck': return <CheckBlance />;
      case 'AadharPay': return <Aeps />;
      case 'AepsMiniStatement': return <StatementSvg />;
      default: return null;
    }
  };

  /* -------------------- 1. STATUS CHECK (Memoized) -------------------- */
  const CheckAeps = useCallback(async () => {
    try {
      const url = activeAepsLine
        ? 'AEPS/api/Nifi/data/AepsStatusCheck'
        : 'AEPS/api/data/AepsStatusCheck';

      const response = await get({ url });

      if (response?.Response === 'Success') {
        setUserStatus('Success');
      } else {
        navigation.navigate('ServicepurchaseScreen', { typename: 'AEPS' });
      }
    } catch (err) {
      console.log('AEPS ERROR:', err);
    }
  }, [activeAepsLine, get, navigation]);

  /* -------------------- 2. EKYC CHECK (Memoized) -------------------- */
  const CheckEkyc = useCallback(async () => {
    // Prevent duplicate calls
    if (isCheckDone.current || isApiCalling.current) return;

    try {
      isApiCalling.current = true;

      const finalUrl = activeAepsLine
        ? 'AEPS/api/Nifi/data/CheckEkyc'
        : APP_URLS.checkekyc;

      const response = await get({ url: finalUrl });

      // Mark check as done so it doesn't loop
      isCheckDone.current = true;

      const msg = response?.Message;
      const status = response?.Status;

      if (status === true) {
        await CheckAeps(); // Proceed to check status
        return;
      }

      if (msg === '2FAREQUIRED') {
        setUserStatus('Success');
        return;
      }

      if (msg === 'REQUIREDOTP') {
        setUserStatus(msg);
        if (activeAepsLine){
           setShowEkycModal(true);

        }else{
          navigation.navigate('Aepsekyc')
        }
        return;
      }

      if (msg === 'REQUIREDSCAN') {
        navigation.navigate('Aepsekycscan');
        return;
      }

      Alert.alert(
        'Notice',
        msg || 'Unknown error',
        [
          {
            text: 'Close',
            onPress: () => console.log('Alert closed'), // Just dismisses the alert
            style: 'cancel', // iOS styling for cancel button
          },
          {
            text: 'Go Back',
            onPress: () => navigation.goBack(), // Navigates back
          },
        ],
        { cancelable: true } // Allows clicking outside the alert to close it (Android)
      );
    } catch (e) {
      console.log('EKYC ERROR:', e);
    } finally {
      isApiCalling.current = false;
    }
  }, [activeAepsLine, get, navigation, CheckAeps]);

  /* -------------------- EFFECT: TRIGGER CHECKS -------------------- */
  useEffect(() => {
    // When 'activeAepsLine' changes (Parent switches tabs), reset lock
    isCheckDone.current = false;

    // Trigger Check
    CheckEkyc();
  }, [activeAepsLine, CheckEkyc]);

  /* -------------------- RENDER -------------------- */
  return (
    <AepsContext.Provider
      value={{
        fingerprintData, setFingerprintData,
        aadharNumber, setAadharNumber,
        consumerName, setConsumerName,
        mobileNumber, setMobileNumber,
        bankName, setBankName,
        scanFingerprint: null,
        setIsValid, isValid,
        deviceName, setDeviceName,
        bankid, setBankId,
      }}
    >
      <View style={styles.container}>
        {UserStatus === 'Success' && (
          <TabView
            lazy
            navigationState={{ index, routes }}
            renderScene={renderScene}
            onIndexChange={setIndex}
            initialLayout={{ width: SCREEN_WIDTH }}
            renderTabBar={(props) => (
              <TabBar
                {...props}
                indicatorStyle={[
                  styles.indicator,
                  { backgroundColor: colorConfig.primaryColor },
                ]}
                style={[styles.tabbar, { backgroundColor: color1 }]}
                renderLabel={({ route, focused }) => (
                  <View style={styles.labelview}>
                    {getSvgimg(route.key)}
                    <Text
                      style={[
                        styles.labelstyle,
                        { color: focused ? colors.dark_black : colors.black75 },
                      ]}
                    >
                      {route.title}
                    </Text>
                  </View>
                )}
              />
            )}
          />
        )}

        {/* ---------------- EKYC MODAL ---------------- */}
        <Modal
          visible={showEkycModal}
          transparent
          animationType="fade"
          onRequestClose={() => setShowEkycModal(false)}
        >
          <View style={styles.modalBg}>
            <View style={styles.modalCard}>
              <Text style={styles.modalTitle}>Green Line</Text>
              <Text style={styles.modalText}>
                Greenline AEPS requires OTP verification.
              </Text>
              <View style={styles.modalActions}>
                <TouchableOpacity onPress={() => setShowEkycModal(false)}>
                  <Text style={styles.backBtn}>Go Back</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.primaryBtn}
                  onPress={() => {
                    setShowEkycModal(false);
                    navigation.replace('Aepsekyc');
                  }}
                >
                  <Text style={{ color: '#fff' }}>Complete eKYC</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </AepsContext.Provider>
  );
};

export default AepsTabScreen;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  tabbar: { elevation: 0, height: hScale(60) },
  indicator: {},
  labelview: { alignItems: 'center' },
  labelstyle: { fontSize: wScale(13), textAlign: 'center' },
  modalBg: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center', alignItems: 'center',
  },
  modalCard: {
    width: '85%', backgroundColor: '#fff',
    borderRadius: 12, padding: 20,
  },
  modalTitle: { fontSize: 18, fontWeight: '700' },
  modalText: { marginVertical: 15, color: '#555' },
  modalActions: { flexDirection: 'row', justifyContent: 'space-between' },
  backBtn: { color: '#f0a500', padding: 10 },
  primaryBtn: { backgroundColor: '#1e7e34', padding: 10, borderRadius: 6 },
});
