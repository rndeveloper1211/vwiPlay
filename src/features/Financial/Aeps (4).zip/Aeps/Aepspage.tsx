import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Alert,
  TouchableOpacity,
  ToastAndroid,
} from 'react-native';
import { useDispatch } from 'react-redux';

import { APP_URLS } from '../../../utils/network/urls';
import useAxiosHook from '../../../utils/network/AxiosClient';
import { hScale, wScale } from '../../../utils/styles/dimensions';

import AppBarSecond from '../../drawer/headerAppbar/AppBarSecond';
import CheckSvg from '../../drawer/svgimgcomponents/CheckSvg';
import AepsTabScreen from './AepsTabScreen';
import ShowLoader from '../../../components/ShowLoder';

import { setActiveAepsLine } from '../../../reduxUtils/store/userInfoSlice';

const AepsScreen = () => {
  const { post } = useAxiosHook();
  const dispatch = useDispatch();

  // 0 = Green, 1 = Yellow
  const [selectedLine, setSelectedLine] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  const isFirstLoad = useRef(true);

  const checkAeps = async (requestedLine: number) => {
    try {
      setIsLoading(true);

      const response = await post({
        url: APP_URLS.AepsStatusCheck,
      });

      const { status1, status2 } = response;

      // 🟢 GREEN LINE
      if (requestedLine === 1) {
        if (status1 === true) {
          dispatch(setActiveAepsLine(true));
          ToastAndroid.show(
            'You are using Green Line AEPS',
            ToastAndroid.BOTTOM
          );
        } else {
          Alert.alert(
            'Service Notice',
            'Green Line AEPS is closed. Switching to Yellow Line.'
          );
          setSelectedLine(1);
        }
      }

      // 🟡 YELLOW LINE
      if (requestedLine === 2) {
        if (status2 === true) {
          dispatch(setActiveAepsLine(false));
          ToastAndroid.show(
            'You are using Yellow Line AEPS',
            ToastAndroid.BOTTOM
          );
        } else {
          Alert.alert(
            'Service Notice',
            'Yellow Line AEPS is closed. Switching to Green Line.'
          );
          setSelectedLine(0);
        }
      }
    } catch (error) {
      console.log('AEPS Status API Error:', error);
      Alert.alert('Error', 'Something went wrong while checking AEPS');
    } finally {
      setIsLoading(false);
    }
  };

  // 🔁 Run check on change
  useEffect(() => {
    if (isFirstLoad.current) {
      isFirstLoad.current = false;
    }
    checkAeps(selectedLine === 0 ? 1 : 2);
  }, [selectedLine]);

  return (
    <View style={styles.container}>
      <AppBarSecond title="AEPS / AADHAAR PAY" />

      {/* 🔘 CUSTOM RADIO BUTTONS */}
      <View style={styles.radioContainer}>
        {/* GREEN LINE */}
        <TouchableOpacity
          style={[
            styles.radioButton,
            styles.greenBg,
            selectedLine === 0 && styles.greenSelected,
          ]}
          onPress={() => setSelectedLine(0)}
        >
          {selectedLine === 0 && (
            <View style={styles.check}>
              <CheckSvg color="#1FAA59" size={16} />
            </View>
          )}
          <Text style={styles.radioText}>Green Line AEPS</Text>
        </TouchableOpacity>

        {/* YELLOW LINE */}
        <TouchableOpacity
          style={[
            styles.radioButton,
            styles.yellowBg,
            selectedLine === 1 && styles.yellowSelected,
          ]}
          onPress={() => setSelectedLine(1)}
        >
          {selectedLine === 1 && (
            <View style={styles.check}>
              <CheckSvg color="#F4C430" size={16} />
            </View>
          )}
          <Text style={styles.radioText}>Yellow Line AEPS</Text>
        </TouchableOpacity>
      </View>

      {/* 🔽 COMMON CONTENT */}
      <AepsTabScreen />

      {isLoading && <ShowLoader />}
    </View>
  );
};

export default AepsScreen;

/* ===================== STYLES ===================== */

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  radioContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: wScale(10),
    paddingVertical: hScale(10),
  },

  radioButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '48%',
    paddingVertical: hScale(10),
    borderRadius: 8,
  },

  greenBg: {
    backgroundColor: '#1FAA59',
  },

  yellowBg: {
    backgroundColor: '#F4C430',
  },

  greenSelected: {
    backgroundColor: '#138D4E',
  },

  yellowSelected: {
    backgroundColor: '#E0C200',
  },

  radioText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },

  check: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: wScale(3),
    marginRight: wScale(6),
  },
});
